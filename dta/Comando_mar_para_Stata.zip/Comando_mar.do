*Definicion del directorio de defecto donde esta el archivo Comando_mar.xlsx
cd "C:\...."

*Ejemplo 1
import excel "Comando_mar.xlsx", sheet("DataTypeRaw") firstrow clear
mar raw or, date(Y) method(fem) interval(se) keep ///
            nst(Enzima convertidora de la angiotensina e infarto de miocardio)

*Uso de los resultados guardados
regress lnor pexp_nc Calidad [aweight = wivf]
metareg lnor pexp_nc Calidad, wsse(se_or) bsest(reml)


*Ejemplo 2
import excel "Comando_mar.xlsx", sheet("DataTypeSST_IC") firstrow clear
mar sst or, influ cum(date) method(rem) forest(se) funnel macask(pexp) ///
            nst(Anticonceptivos orales y adenocarcinoma de cuello uterino)

*Ejemplo 3
import excel "Comando_mar.xlsx", sheet("DataTypeMixed") firstrow clear
mar mix or, date(Y) begg


*Ejemplo 4
import excel "Comando_mar.xlsx", sheet("DataTypeRawZ") firstrow clear
mar raw rr

*Ejemplo 5
mar raw rr, zero(e) keep

gsort -se_rr  // Ordena los estudios de mayor a menor error estandar
metan a1 b1 a0 b0, rr fixed label(namevar=study) effect(Risk ratio) nointeger texts(245)

metan a1 b1 a0 b0, rr fixedi label(namevar=study) effect(Risk ratio) nointeger texts(245)
metan lnrr se_rr, fixedi eform label(namevar=study) effect(Risk ratio) texts(245)
*************************
metaan lnrr se, fe forest
di exp(r(eff))
di exp(r(efflo))
di exp(r(effup))
*************************

*Ejemplo 6
import excel "Comando_mar.xlsx", sheet("DataTypeRawM") firstrow clear
replace m1=-m1 if study=="Lehman" //Puntuacion en sentido inverso
replace m0=-m0 if study=="Lehman" 
mar raw md, cohen influ method(rem) forest(se) keep ///
    nst(Assertive comm. treat. for mental disorders (Egger, Smith & Altman; 2001, p. 305))

*Ejemplo 7
import excel "Comando_mar.xlsx", sheet("DataTypeSSTrN") firstrow clear
mar sst r, influ method(fem) forest(se)
